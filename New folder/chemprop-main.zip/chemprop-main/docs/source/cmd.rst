.. _cmd:

CLI Reference
*************

.. contents:: Table of Contents
    :depth: 3
    :local:

.. argparse::
    :ref: chemprop.cli.main.construct_parser
    :prog: chemprop

---
name: to-do
about: Add an item to the to-do list. More generic than a feature request
title: "[TODO]: "
labels: todo
assignees: ''

---

**Notes**
_these could be implementation or more specific details to keep in mind, if they'll be helpful for issue tracking_

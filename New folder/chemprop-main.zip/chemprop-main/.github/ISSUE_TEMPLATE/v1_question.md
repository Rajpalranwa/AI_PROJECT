---
name: v1 Question
about: Have a question about how to use Chemprop v1?
title: "[v1 QUESTION]: "
labels: question
assignees: ''

---

**What are you trying to do?**
Please tell us what you're trying to do with Chemprop, providing as much detail as possible

**Previous attempts**
If possible, provide some examples of what you've already tried and what the output was.

**Screenshots**
If applicable, add screenshots to help explain your problem.
